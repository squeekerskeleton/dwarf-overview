"""DWARF Post-Processing Hub: assess DWARF 3 astrophotos with Claude and plan the processing."""
__version__ = "0.14.0"
